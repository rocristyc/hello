# test this python module to use it in a jenkins job
# Define a function
def world():
    print("Hello, World!")
